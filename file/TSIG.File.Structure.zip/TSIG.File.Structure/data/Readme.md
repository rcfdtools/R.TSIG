# Data source

`\data`: carpeta para el almacenamiento de los datos base suministrados o descargados para cada taller o para el proyecto.

> No incluya en esta carpeta documentos de referencias bibliográficas, tales como libros de uso libre, artículos, informes técnicos recopilados. Utilice la carpeta \ref.

	