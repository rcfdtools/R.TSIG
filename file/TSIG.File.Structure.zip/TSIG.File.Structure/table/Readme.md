# Tablas de datos

`\table`: carpeta para el almacenamiento tablas de datos como: archivos de texto .txt, .asc diferentes de grillas, textos separados por comas .csv, archivos de Microsoft Excel .xls o .xlsx, archivos DBase File .dbf y bases de datos no espaciales en formato de Microsoft Access .mdb , .accdb o .accde , sqlite, Oracle.

