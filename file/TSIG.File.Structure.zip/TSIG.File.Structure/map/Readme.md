# Mapas de proyecto

`\map`: carpeta para el almacenamiento de mapas de proyecto, vistas de globo y escenas geográficas.

Tipos de archivos o directorio

* ArcGISPro: carpeta de proyecto general de ArcGIS Pro. Internamente incluye mapas y vistas de datos geográficos.
* .mxd: mapa de ArcGIS for Desktop
* .mxt: plantilla de mapa en ArcGIS for Desktop
* .sxd: escena de ArcGIS for Desktop
* .qgz: mapa de QGIS