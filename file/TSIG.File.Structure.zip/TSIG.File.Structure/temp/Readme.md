# Directorio temporal de datos

`\temp`: carpeta para el almacenamiento temporal de datos que pueden ser eliminados completamente en cualquier momento. Por ejemplo, para la realización de pruebas preliminares o revisión de archivos descargados, antes de su incorporación a las carpetas oficiales del taller o el proyecto.

